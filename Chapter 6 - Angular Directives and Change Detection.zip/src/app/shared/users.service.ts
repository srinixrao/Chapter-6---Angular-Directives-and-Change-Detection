import { Injectable } from '@angular/core';

@Injectable()
export class UsersService {

  constructor() { }

  getUsers() {
    console.log("Write logic to get list of users");
  }
}
