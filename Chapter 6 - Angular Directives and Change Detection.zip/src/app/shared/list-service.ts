import { Injectable } from '@angular/core';

@Injectable()

export class ListService {
  getList() { 
  	console.log("Injectable List Service")
  }
}