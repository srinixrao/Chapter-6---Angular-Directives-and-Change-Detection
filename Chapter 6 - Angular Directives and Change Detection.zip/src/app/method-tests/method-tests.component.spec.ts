import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MethodTestsComponent } from './method-tests.component';
/*
describe('MethodTestsComponent', () => {

  it('should calculate taxes', () => {
    let component = new MethodTestsComponent();
    expect(component.total_tax).toBe(30);
  });

});
*/