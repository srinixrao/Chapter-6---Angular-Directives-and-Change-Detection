
export class Vehicle {  
    public speed: string;
    constructor(speed: string) {
        this.speed = speed;
    }
} 